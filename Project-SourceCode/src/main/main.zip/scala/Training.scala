// Loading necessary library
import org.apache.spark.sql.functions._
import org.apache.spark.sql.DataFrame
// Machine Learning lib
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.feature.{HashingTF,IDF, Tokenizer}
import org.apache.spark.ml.tuning.{CrossValidator, ParamGridBuilder}
import org.apache.spark.ml.feature.StopWordsRemover
import org.apache.spark.ml.feature.CountVectorizer
import org.apache.spark.ml.classification.{LogisticRegression, OneVsRest}

import org.apache.spark.mllib.evaluation.MulticlassMetrics
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.ml.classification.LinearSVC

import org.apache.spark.ml.evaluation.BinaryClassificationEvaluator
import org.apache.spark.ml.feature.{Word2Vec,Word2VecModel}
import org.apache.spark.mllib.evaluation.MulticlassMetrics

import org.apache.spark.ml.classification.{DecisionTreeClassificationModel,DecisionTreeClassifier}
import org.apache.spark.ml.classification.{RandomForestClassificationModel, RandomForestClassifier}
import org.apache.spark.ml.classification.{GBTClassificationModel, GBTClassifier}
import org.apache.spark.ml.classification.{NaiveBayes,NaiveBayesModel}
import org.apache.spark.sql.types._
import org.apache.spark.ml.classification.{MultilayerPerceptronClassifier,MultilayerPerceptronClassificationModel}
import org.apache.spark.sql.SparkSession
object Training {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().master("local[2]")
      .appName("Twitter Comment Sentiment")
      .getOrCreate()

    // ========================================== PARAMETERS =======================================================
    // Change paremeters to build model for different label "toxic","severe_toxic","obscene","threat","insult","identity_hate"
    val colName = "identity_hate"

    // ======================================== Load Clean data =====================================================
    //Train data
//    "../../resources/example.txt"
     val train_url = "src/main/resources/data_train_clean.csv"
     val data_train = spark.read.option("header", "true").option("inferSchema",true).csv(train_url)
    // Test data
    val test_url = "src/main/resources/data_test_clean.csv"
    val data_test = spark.read.option("header", "true").option("inferSchema",true).csv(test_url)
    // ======================================= Feature Extraction ======================================
    // (Tokenizer -> StopWord Filter -> TFIDF / Word2Vec / CountVectorizer )
    // Reference
    // https://www.kaggle.com/danielokeeffe/text-classification-with-apache-spark

    val tokenizer = new Tokenizer().setInputCol("clean_comment").setOutputCol("words")
    val stopWord = new StopWordsRemover().setInputCol(tokenizer.getOutputCol).setOutputCol("stopWordFilter")

    val hashingTF = new HashingTF().setInputCol(stopWord.getOutputCol).setOutputCol("features")
    // val idf = new IDF().setInputCol("stopWord.getOutputCol").setOutputCol("features")

    // val countVector = new CountVectorizer().setInputCol(stopWord.getOutputCol)
    // .setOutputCol("features")
    // .setVocabSize(3)
    // .setMinDF(10)

    val word2Vec = new Word2Vec()
      .setInputCol("stopWordFilter")
      .setOutputCol("features")
      //   .setVectorSize(30)
      //   .setMaxSentenceLength() // Desult:1000
      .setVectorSize(100)
      .setMinCount(5)



    // val pipeline = new Pipeline().setStages(Array(tokenizer, stopWord,hashingTF)).fit(data_train)
    // val pipeline = new Pipeline().setStages(Array(tokenizer, stopWord,countVector)).fit(data_train)
    val pipeline = new Pipeline().setStages(Array(tokenizer, stopWord,word2Vec)).fit(data_train)

    var data_train_pro = pipeline.transform(data_train).select("id","features","toxic","severe_toxic","obscene","threat","insult","identity_hate")
    // data_train_pro = balanceDataset(data_train_pro,colName)
    // data_train_pro = balanceDataset_force(data_train_pro,colName)
    val data_test_pro = pipeline.transform(data_test).select("id","features","toxic","severe_toxic","obscene","threat","insult","identity_hate")

    pipeline.write.save("src/main/pipeline/pipeline_word2vec")


    // ========================================== Neural Network =========================================
    val layers = Array[Int](100,20, 10,2)

    val NN = new MultilayerPerceptronClassifier()
      .setLayers(layers)
      .setSeed(1234L)
      .setMaxIter(1000)
      .setLabelCol(colName)

  }
}
