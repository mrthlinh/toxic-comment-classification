import org.apache.spark.ml.PipelineModel
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.ml.classification.{MultilayerPerceptronClassificationModel, MultilayerPerceptronClassifier}

object toxicityExample {
  val spark = SparkSession.builder().master("local[2]")
    .appName("Twitter Comment Sentiment")
    .getOrCreate()
  import spark.implicits._

  def main(args: Array[String]): Unit = {
//    val spark = SparkSession.builder().master("local[2]")
//      .appName("Twitter Comment Sentiment")
//      .getOrCreate()
//    import spark.implicits._
    val message = "Fuck Trump" // String
    val message_df = spark.sparkContext.parallelize(List(message)).toDF("clean_comment") // Convert to DF, need spark.implicits
    val toxic_type = toxicity_type(message_df) // You get the Map here "toxic","severe_toxic","obscene","threat","insult","identity_hate"

    println(toxic_type.keySet) // Get Key
    println(toxic_type.values) // Get Value
    println(toxic_type)

  }
  def toxicity_type(message: DataFrame): Map[String,Int] = {

    // Load Pipeline of Pre-processing
    val pipeline_pre = PipelineModel.read.load("src/main/pipeline/pipeline_word2vec")

    // Load 6 models "toxic","severe_toxic","obscene","threat","insult","identity_hate"
    val NN_model_toxic = MultilayerPerceptronClassificationModel.read.load("src/main/pipeline/NN_toxic")
    val NN_model_severe = MultilayerPerceptronClassificationModel.read.load("src/main/pipeline/NN_severe_toxic")
    val NN_model_obscene = MultilayerPerceptronClassificationModel.read.load("src/main/pipeline/NN_obscene")
    val NN_model_threat = MultilayerPerceptronClassificationModel.read.load("src/main/pipeline/NN_threat")
    val NN_model_insult = MultilayerPerceptronClassificationModel.read.load("src/main/pipeline/NN_insult")
    val NN_model_hate = MultilayerPerceptronClassificationModel.read.load("src/main/pipeline/NN_identity_hate")

    // Run message through the Pipeline Pre-processing
    val message_df = pipeline_pre.transform(message)

    // Run message through the 6 Neural Net model
    val result_toxic = NN_model_toxic.transform(message_df).select("prediction").map(x => x.getDouble(0)).collect()(0).toInt
    val result_severe = NN_model_severe.transform(message_df).select("prediction").map(x => x.getDouble(0)).collect()(0).toInt
    val result_obscene = NN_model_obscene.transform(message_df).select("prediction").map(x => x.getDouble(0)).collect()(0).toInt
    val result_threat = NN_model_threat.transform(message_df).select("prediction").map(x => x.getDouble(0)).collect()(0).toInt
    val result_insult = NN_model_insult.transform(message_df).select("prediction").map(x => x.getDouble(0)).collect()(0).toInt
    val result_hate = NN_model_hate.transform(message_df).select("prediction").map(x => x.getDouble(0)).collect()(0).toInt

    // Return Array
//    val resultArray = Array(result_toxic, result_severe,result_obscene,result_threat,result_insult,result_hate)

    // Return Map
    val resultMap = Map("toxic" -> result_toxic, "severe toxic" -> result_severe
                        ,"obscene" -> result_obscene, "threat" -> result_threat
                        ,"insult" -> result_insult, "identity hate" -> result_hate )
    resultMap
  }
}